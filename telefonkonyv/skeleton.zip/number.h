#ifndef NUMBER_H
#define NUMBER_H
#include<iostream>

using namespace std;

class Number{
    int areacode;
    string number;

public:
    Number():areacode(0), number(""){}
    Number(int areacode, string number):areacode(areacode), number(number){} ///ctor

    int getAreacode() const{  ///email getter
        return areacode;
    }
    void setAreacode(int areacode) { ///email setter
        this->areacode=areacode;
    }

    string getNumber() const{  ///email getter
        return number;
    }
    void setNumber(string number) { ///email setter
        this->number=number;
    }
};

std::istream& operator>> (istream& is, Number& n) {
    cout << "Enter the areacode" << endl;
    string input_string = "";
    int input_int = 0;
    is >> input_int;
    n.setAreacode(input_int);
    cout << "Enter the phonenumber" << endl;
    is >> input_string;
    n.setNumber(input_string);
    return is;
}

std::ostream& operator<< (ostream& os, Number& n) {
    cout << n.getAreacode() << ";" << n.getNumber() << ";";
    return os;
}

#endif
