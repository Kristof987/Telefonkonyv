#include <iostream>
#include <string>
#include <sstream>

#include "address.h"
#include "book.h"
#include "econio.h"
#include "menu.h"
#include "memtrace.h"
#include "student.h"
#include "adult.h"
#include "retired.h"
#include "record.h"
#include "gtest_lite.h"



//using namespace::std;

/*class Hibak {
public:
    //nem hasznalom semmire, kesobb gtest lite keretrendszer lesz hasznalva teszteleshez
    Hibak(const string&) {}
};*/

///még nagyon kezdetleges, de minden részletre kiterjedõ lesz végül
///konstruktorok, getterek, setterek, kiiro operator kerul tesztelesre

int main()  {
   GTINIT(std::cin);       // Csak C(J)PORTA működéséhez kell

    TEST(TEST1,NullParamKonstr){ //default konstruktor
        Address a;
        EXPECT_EQ(0, a.getPostalcode());
    } END

    TEST(TEST2,MasikKonstr){ //konstruktor
        Address cim(3524, "Miskolc", "Utca", "Szam");
        Number n1(36, "709423240");
        Number n2(36, "666666666");
        Student s(cim, n1, n2, "Feri", "Ferike", "valami@gmail.com", "nincskomment", "BME");
        EXPECT_STREQ("BME",s.getSchool().c_str());
    } END

    TEST(TEST3,Setter){
        Retired oreg;
        oreg.setHobby("keresztrejtveny");
    } END

    TEST(TEST4,op<<){ //konstruktor
        Address cim(3524, "Miskolc", "Utca", "Szam");
        Number n1(36, "709423240");
        Number n2(36, "666666666");
        Student s(cim, n1, n2, "Feri", "Ferike", "valami@gmail.com", "nincskomment", "BME");
        std::cout<<s<<endl;
    } END


    GTEND(std::cerr);
    return 0;
}
