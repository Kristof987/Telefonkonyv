#ifndef ADULT_H
#define ADULT_H

#include "record.h"

class Adult:public Record{
    string workplace;
    Adult* pointer;
public:
    Adult(Address address,
            Number worknumber,
            Number phonenumber,
            string name,
            string nickname,
            string email,
            string comment,
            string workplace)
            :Record(address,worknumber,phonenumber,name,nickname,email,comment)
            ,workplace(workplace){}
    Adult()
            :Record()
            ,workplace(""){}

    string getWorkplace() const{  ///email getter
        return workplace;
    }
    void setWorkplace(string workplace) { ///email setter
        this->workplace=workplace;
    }

};

std::istream& operator>>(std::istream& is, Adult& a){
    Record* r;
    r = &a;
    cin>>*r;
    cout << "Enter the workplace" <<endl;
    string input = "";
    is >> input;
    a.setWorkplace(input);
    return is;
}

std::ostream& operator << (ostream& os, Adult& a) {
    Record* r;
    r=&a;
    cout<<*r;
    cout << a.getWorkplace()<<";";
    return os;
}

#endif
