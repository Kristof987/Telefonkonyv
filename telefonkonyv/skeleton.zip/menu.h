﻿#ifndef MENU_H
#define MENU_H
#include <stdlib.h>

void menu_cout();
void menu();
void search_menu();
void search_menu_cout();

void menu_cout(){
    system("CLS");
    cout << "                                        *********TELEFONKONYV*********"<<endl<<endl;
    cout << "                                        ***Valassz az opciok kozul!***"<<endl<<endl;
    cout << "                           (1) Szerkesztes          (2) Hozzaadas            (3) Torles"<<endl;
    cout << "                           (4) Listazas             (5) Kereses              (6) Kilepes"<<endl;

}

void search_menu_cout(){
    //econio_clrscr();
    cout << endl
         << "                                       Melyik rekordban szeretnel keresni?" <<endl << endl << endl;
    cout << "                           (1) Nev                    (2) Becenev              (3) Lakcim"<<endl<<endl;
    cout << "                                       (4) E-mail               (5) Komment"            <<endl<<endl;
    cout << "                           (6) Munkahelyi telefonszam (7) Maganszam            (8) Vissza"<<endl;
}

void menu(){
    int choice=0;
    while (choice!=9999999){
        menu_cout();
        cin >> choice;
        switch(choice){
        case 1:
            cout << "Szerkesztes menu";
            //Beolvas
            //Keresés
            //Adatsor törlése
            //Új adat bekérése
            //Uniq adatok ellenörzése
            //Kiírás fájlba
            //Memória Felszabadít
            break;
        case 2:
            cout << "Hozzaadas menu";
            //Beolvasás
            //Adatbekérés
            //Uniq adatok ellenörzése
            //Hozzáfűzés
            //Kiírás fájlba
            //Memória Felszabadít
            break;
        case 3:
            //Beolvasás
            //Keresés
            //Törlése
            //Kiírás fájlba
            //Memória Felszabadít
            break;
        case 4:
            //Beolvasás
            //Rendezés -> Név alapján
            //Kiírás
            //Memória Felszabadít
            break;
        case 5:
            //Beolvas
            search_menu_cout();
            search_menu();
            //Memória Felszabadít
            break;
        case 6:
            exit(0);
            break;
        default:
            cout<<"Hibas karakter"<<endl;
            cout<<"1-7 kozotti szamokat adj meg"<<endl;
            cout<<"Nyomj meg egy gombot a menube valo visszatereshez!"<<endl;
        }
    }
}

void search_menu(){
    //Egyszer fusson le
    int choice;
    cin >> choice;
        switch(choice){
        case 1:
            cout << "Nevre kereses menu";
            //Beolvas
            //search_for_name()
            //Kiír
            //Memóra felszavadít
            break;
        case 2:
            //Beolvas
            //search_for_name()
            //Kiír
            //Memóra felszavadít
            break;
        case 3:
            break;
        case 4:
            break;
        case 5:
            search_menu();
            break;
        case 6:
            break;
        case 7:
            break;
        case 8:
            //econio_clrscr();
            menu_cout();
            break;
        default:
            cout<<"Hibas karakter"<<endl;
            cout<<"1-8 kozotti szamokat adj meg"<<endl;
            cout<<"Nyomj meg egy gombot a menube valo visszatereshez!"<<endl;

    }
}

#endif
