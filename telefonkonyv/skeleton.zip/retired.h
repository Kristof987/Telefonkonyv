#ifndef RETIRED_H
#define RETIRED_H

#include "record.h"

class Retired:public Record{
    string hobby;
    Retired* pointer;
public:
    Retired(Address address,
            Number worknumber,
            Number phonenumber,
            string name,
            string nickname,
            string email,
            string comment,
            string hobby)
            :Record(address,worknumber,phonenumber,name,nickname,email,comment)
            ,hobby(hobby){}

    Retired()
            :Record()
            ,hobby(""){}

    string getHobby() const{  ///email getter
        return hobby;
    }
    void setHobby(string hobby) { ///email setter
        this->hobby=hobby;
    }

};

std::istream& operator>>(std::istream& is, Retired& rr){
    Record* r;
    r = &rr;
    cin>>*r;
    cout << "Enter your hobby" <<endl;
    string input = "";
    is >> input;
    rr.setHobby(input);
    return is;
}

std::ostream& operator << (ostream& os, Retired& re) {
    Record* r;
    r=&re;
    cout<<*r;
    cout << re.getHobby()<<";";
    return os;
}

#endif
