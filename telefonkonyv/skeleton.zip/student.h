#ifndef STUDENT_H
#define STUDENT_H

#include "record.h"

class Student:public Record{
    string school;
public:
    Student* pointer;
    Student(Address address,
            Number worknumber,
            Number phonenumber,
            string name,
            string nickname,
            string email,
            string comment,
            string school):Record(address,worknumber,phonenumber,name,nickname,email,comment),
            school(school){}

    Student():Record(),
            school(""){}

    string getSchool() const{  ///email getter
        return school;
    }
    void setSchool(string school) { ///email setter
        this->school=school;
    }

};

std::istream& operator>>(std::istream& is, Student& s){
    Record* r;
    r = &s;
    cin>>*r;
    cout << "Enter the school" <<endl;
    string input = "";
    is >> input;
    s.setSchool(input);
    return is;
}

std::ostream& operator << (ostream& os, Student& s) {
    Record* r;
    r=&s;
    cout<<*r;
    cout << s.getSchool()<<";";
    return os;
}

#endif
