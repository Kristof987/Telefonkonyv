#ifndef BOOK_H
#define BOOK_H

#include "record.h"
#include <fstream>

template <class T>
class Book{
    T* pointer;
    size_t siz;
public:
    //Book():siz(0),Book(new Record*[siz]){}
    //Book(const Book& b) {} ///copy ctor
    //Book<Student>() {}
    void read_from_file(fstream &szoveg,Record* r){  //meg hibas
        if(szoveg.bad()) throw "baj van biza!";
        int idx = 0;
        while(szoveg.good()){
            szoveg>>r[idx];
            idx++;
        }
        szoveg.close();
    }

    void write_to_file(){}

    //template<class F>
    void add(T* p) //meg hibas
    {
        T* point = this->pointer;
        while (point != NULL)
        {
            point = point.pointer;
        }
        pointer = point;
    }
    void list_record(T* p) {}
    void search_record (T* p){} //meg bovitem szabad kulcsszavasra
    void delete_record (T* p){}
    void edit_record (T* p){}
};


#endif
