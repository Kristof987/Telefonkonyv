
#ifndef ADDRESS_H
#define ADDRESS_H

using namespace std;

class Address{
    int postalcode;
    string city;
    string streetname;
    string number; ///szam es ajto
public:
    Address():postalcode(0),city(""),streetname(""),number(""){}
    Address(int postalcode, string city, string streetname, string number):postalcode(postalcode),city(city),streetname(streetname),number(number){}
    int getPostalcode() const{  ///email getter
        return postalcode;
    }
    void setPostalcode(int postalcode) { ///email setter
        this->postalcode=postalcode;
    }
    string getCity() const{  ///email getter
        return city;
    }
    void setCity(string City) { ///email setter
        this->city= City;
    }
    string getStreetname() const{  ///email getter
        return streetname;
    }
    void setStreetname(string streetname) { ///email setter
        this->streetname=streetname;
    }
    string getNumber() const{  ///email getter
        return number;
    }
    void setNumber(string number) { ///email setter
        this->number=number;
    }
};

std::istream& operator>> (istream& is, Address& a) {
    cout << "Enter the postalcode" << endl;
    string input_string = "";
    int input_int = 0;
    is >> input_int;
    a.setPostalcode(input_int);
    cout << "Enter the city" << endl;
    is >> input_string;
    a.setCity(input_string);
    cout << "Enter the streetname" << endl;
    is >> input_string;
    a.setStreetname(input_string);
    cout << "Enter the number" << endl;
    is >> input_string;
    a.setNumber(input_string);
    return is;
}

std::ostream& operator << (ostream& os, Address& a) {
    cout << a.getPostalcode() << ";" << a.getCity() << ";" << a.getStreetname() << ";" << a.getNumber() << ";" ;
    return os;
}
#endif
