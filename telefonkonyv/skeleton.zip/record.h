#ifndef RECORD_H
#define RECORD_H

#include "number.h"
#include "address.h"
#include<iostream>

class Record:public Address{
protected:

            Number worknumber;
            Number phonenumber;
            string name; ///nev
            string nickname; ///becenev
            string email; ///email
            string comment; ///komment
public:
    Record(): ///ctor
        Address(), name(""), nickname(""), email(""), comment("") {}

    Record(Address address, Number worknumber, Number phonenumber,string name, string nickname, string email, string comment): ///ctor
        Address(address),worknumber(worknumber),phonenumber(phonenumber),name(name), nickname(nickname),email(email), comment(comment) {}




    Number& getWorknumber() /*const*/{  ///name getter
        return worknumber;
    }
    void setWorknumber(Number worknumber) { ///name setter
        this->worknumber=worknumber;
    }

    Number& getPhonenumber() /*const*/{ ///nickname getter
        return phonenumber;
    }
    void setPhonenumber(Number phonenumber){ ///nickname getter
        this->phonenumber=phonenumber;
    }

    string getName() const{  ///email getter
        return name;
    }
    void setName(string name) { ///email setter
        this->name=name;
    }

    string getNickname() const{  ///email getter
        return nickname;
    }
    void setNickname(string nickname) { ///email setter
        this->nickname=nickname;
    }

    string getEmail() const{  ///email getter
        return email;
    }
    void setEmail(string email) { ///email setter
        this->email=email;
    }

    string getComment() const{  ///comment getter
        return comment;
    }
    void setComment(string comment) { ///comment setter
        this->comment=comment;
    }
};

std::istream& operator>> (istream& is, Record& r){
    cout << "Enter the name" <<endl;
    string input = "";
    is >> input;
    r.setName(input);
    cout << "Enter the nickname" << endl;
    is >> input;
    r.setNickname(input);
    cout << "Enter the email" << endl;
    is >> input;
    r.setEmail(input);
    cout << "Enter the comment" << endl;
    is >> input;
    r.setComment(input);
    cout << "Enter your phonenumber" << endl;
    Number input_number;
    cin >> input_number;
    r.setPhonenumber(input_number);
    cout << "Enter your worknumber" << endl;
    cin >> input_number;
    r.setWorknumber(input_number);
    Address* p;
    p = &r;
    cin >> *p;
    return is;
}

std::ostream& operator << (ostream& os, Record& r) {
    Address *a;
    a=&r;
    cout << r.getName() << ";" << r.getNickname() << ";" << r.getEmail() << ";" << r.getComment() << ";";
    cout << r.getPhonenumber() << r.getWorknumber();
    cout << *a;
    return os;
}

#endif
